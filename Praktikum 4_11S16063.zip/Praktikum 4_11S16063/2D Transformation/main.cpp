/* Praktikum 5*/
/*11S16063*/
/*Dolly Lesmana*/



/*
    * Program : P06P01.cpp
    * Title   : Translation, Rotation, dan Scallng
    * Purpose : Transoformasi primitif dari model space ke world space (local ke global)

    */

    #include <windows.h> // untuk MS Winodows
    #include <GL/glut.h> // GLUT (include glu.h and gl.h)

    /* Inisialisasi OpenGL Graphics */
void initGL(){
    //Set {clearing} or background color
    glClearColor(1.0f, 1.0f, 1.0f, 0.0f); //Putih
    }

void persegi(){
  glBegin(GL_QUADS);              // Setiap set 4 vertex membentuk sebuah quad
    glColor3f(0.0f, 0.0f, 0.0f);    //Hitam
    //Definisikan vertex berlawanan jarum jam (counter-clockwise)
    glVertex2f(-0.8f, -0.5f);       //Kiri bawah
    glColor3f(1.0f, 1.0f, 0.0f);    //Kuning
    glVertex2f(-0.3f, -0.5f);       //Kanan bawah
    glColor3f(1.0f, 0.0f, 1.0f);    //Fuchasia
    glVertex2f(-0.3f, 0.0f);        //Kanan atas
    glColor3f(0.0f, 1.0f, 1.0f);    //Aqua
    glVertex2f(-0.8f, 0.0f);        //Kiri atas
    glEnd();
    }
    /*Handler untukwindow-repaint event. Panggi; ketika window muncul untuk pertama kali dan kapanpun
      window-repaint diperlukan */

void display(){
        glClear(GL_COLOR_BUFFER_BIT);   //Bersihkan color buffer
        glMatrixMode(GL_MODELVIEW);     //operasikan pada Model-view matrix
        glLoadIdentity();               // Reset model-view matirx


        //Tampilkan x-axis dan y-axis
        glBegin(GL_LINES);
        glColor3f(0.0f, 0.0f, 0.0f);    //Hitam
        glVertex2f(-1.0f, 0.0f);
        glVertex2f(1.0f, 0.0f);
        glVertex2f(0.0f, -1.0f);
        glVertex2f(0.0f, 1.0f);
        glEnd();

        persegi();                      // Tampilkan persegi setelah ditarnsformasi
        glFlush();                      //  Render
    }

    /*Handler untuk window re-size event, Panggil ketika window muncul untuk pertama kali dan kapanpun window-re-size dengan nilai
      width dan height yang baru diperlukan
      */

void reshape(GLsizei width, GLsizei height){    // GLseizei untuk non-negative integer
    //kalkulasi aspek rasio window baru
    if (height == 0) height = 1;                // To prevent divide by 0
    GLfloat aspect = (GLfloat)width / (GLfloat) height;

    //Atur vieewport untuk meng-cover window baru
    glViewport(0, 0, width, height);

    //Atur aspek rasio clipping area untuk menyesuaikan viewport
    glMatrixMode(GL_PROJECTION);                // To operate on the Projection matrix
    glLoadIdentity();
    if(width >= height){
        //aspek >= 1, atur height dari -1 ke 1, dengan width lebih besar
        gluOrtho2D(-1.0 *aspect, 1.0 * aspect, -1.0, 1.0);

    } else{
        //aspek < 1, atur width dari -1 ke 1, dengan height lebih besar
        gluOrtho2D(-1.0, 1.0, -1.0/aspect, 1.0/ aspect);
    }
}

/*Main function: GLUT berjalan sebagai aplikasi console dimulai pda main() */
int miain(int argc, char** argv){
    glutInit(&argc, argv);              // Inisialisasi GLUT
    glutInitWindowSize(500, 500);       // Atur window's initial width & height - non-square
    glutInitWindowPosition(50, 50);     // Posisikan window's initial top-left corner
    glutCreateWindow("Basic 2D Transformation");    // Buat window dilengkapi judul
    glutDisplayFunc(display);           //Register callback handler untuk window re-paint event
    glutReshapeFunc(reshape);           //Register callback handler untuk window re-size event
    initGL();                           //Inisialisasi OpenGL yang dibangun
    glutMainLoop();                     //Masukkan infinite event-processing loop
    return 0;
}
